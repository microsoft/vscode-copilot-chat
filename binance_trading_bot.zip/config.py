#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration management for the trading bot
"""

import os
import json
import logging

logger = logging.getLogger(__name__)

class Config:
    """Configuration manager"""
    
    # Default configuration
    DEFAULT_CONFIG = {
        'symbol': 'BTCUSDT',
        'risk_percent': 0.01,
        'strategy': 'SMA_CROSSOVER',
        'bot_active': True,
        'testnet': True,
        'indicator_settings': {
            "SMA_CROSSOVER": {
                "short_window": 20,
                "long_window": 50,
                "threshold": 0.002
            },
            "RSI": {
                "period": 14,
                "oversold": 30,
                "overbought": 70
            },
            "BOLLINGER": {
                "period": 20,
                "std_dev": 2
            }
        },
        'risk_management': {
            "dynamic_risk": True,
            "max_daily_risk": 0.05,
            "trailing_stop": True,
            "trail_percent": 0.5,
            "stop_loss": 1.0
        }
    }
    
    @staticmethod
    def get_api_credentials():
        """Get API credentials from environment variables"""
        return {
            'api_key': os.environ.get('BINANCE_API_KEY'),
            'api_secret': os.environ.get('BINANCE_API_SECRET'),
            'telegram_token': os.environ.get('TELEGRAM_BOT_TOKEN'),
            'telegram_chat_id': os.environ.get('TELEGRAM_CHAT_ID')
        }
    
    @staticmethod
    def validate_credentials():
        """Validate API credentials"""
        creds = Config.get_api_credentials()
        if not creds['api_key'] or not creds['api_secret']:
            return False, "Binance API credentials not found in environment variables"
        return True, "Credentials validated"
    
    @staticmethod
    def load_config(config_file='bot_config.json'):
        """Load configuration from file"""
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Create default config file
                Config.save_config(Config.DEFAULT_CONFIG, config_file)
                return Config.DEFAULT_CONFIG
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return Config.DEFAULT_CONFIG
    
    @staticmethod
    def save_config(config, config_file='bot_config.json'):
        """Save configuration to file"""
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving config: {e}")
            return False
