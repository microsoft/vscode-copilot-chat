#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Advanced Binance Trading Bot with Multiple Strategies
"""

try:
    from binance.client import Client
    from binance.exceptions import BinanceAPIException, BinanceOrderException
except ImportError:
    # Fallback for development/testing
    class Client:
        ORDER_TYPE_MARKET = "MARKET"
        KLINE_INTERVAL_1HOUR = "1h"
        def __init__(self, api_key, api_secret, testnet=True):
            self.api_key = api_key
            self.api_secret = api_secret
            self.testnet = testnet
    
    class BinanceAPIException(Exception):
        def __init__(self, message, status_code=None):
            super().__init__(message)
            self.status_code = status_code
            self.message = message
    
    class BinanceOrderException(Exception):
        def __init__(self, message, status_code=None):
            super().__init__(message)
            self.status_code = status_code
            self.message = message
import time
import math
import requests
import threading
import numpy as np
from datetime import datetime, timedelta
import json
import os
import logging
from logging.handlers import RotatingFileHandler
import sys
import hashlib
import hmac

# Setup logging
def setup_logging():
    """Setup logging system"""
    log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # File handler with rotation
    file_handler = RotatingFileHandler('trading_bot.log', maxBytes=5*1024*1024, backupCount=3)
    file_handler.setFormatter(log_formatter)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)
    
    # Main logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logging()

class TradingBotConfig:
    """Configuration manager for the trading bot"""
    def __init__(self):
        self.config_file = "bot_config.json"
        self.default_config = {
            'symbol': 'BTCUSDT',
            'risk_percent': 0.01,
            'strategy': 'SMA_CROSSOVER',
            'bot_active': True,
            'indicator_settings': {
                "SMA_CROSSOVER": {"short_window": 20, "long_window": 50, "threshold": 0.002},
                "RSI": {"period": 14, "oversold": 30, "overbought": 70},
                "BOLLINGER": {"period": 20, "std_dev": 2}
            },
            'risk_management': {
                "dynamic_risk": True,
                "max_daily_risk": 0.05,
                "trailing_stop": True,
                "trail_percent": 0.5,
                "stop_loss": 1.0
            }
        }
        self.config = self.default_config.copy()
    
    def load(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # Merge configurations
                    for key in self.default_config:
                        if key in loaded_config:
                            if isinstance(self.default_config[key], dict):
                                self.config[key].update(loaded_config[key])
                            else:
                                self.config[key] = loaded_config[key]
                    logger.info("Configuration loaded successfully")
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
            self.save()
    
    def save(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("Configuration saved successfully")
        except Exception as e:
            logger.error(f"Error saving configuration: {str(e)}")
    
    def get(self, key):
        """Get configuration value"""
        return self.config.get(key, self.default_config.get(key))
    
    def set(self, key, value):
        """Set configuration value"""
        if key in self.config:
            if isinstance(self.config[key], dict) and isinstance(value, dict):
                self.config[key].update(value)
            else:
                self.config[key] = value
        else:
            self.config[key] = value

class TradeManager:
    """Manage active trades and history"""
    def __init__(self):
        self.active_trades = {}
        self.trade_history = []
        self.lock = threading.Lock()
    
    def add_trade(self, symbol, side, entry_price, quantity, stop_price=None):
        """Add new trade"""
        with self.lock:
            self.active_trades[symbol] = {
                'side': side,
                'entry_price': entry_price,
                'quantity': quantity,
                'stop_price': stop_price,
                'entry_time': datetime.utcnow(),
                'highest_price': entry_price if side == 'BUY' else None,
                'lowest_price': entry_price if side == 'SELL' else None
            }
    
    def update_trade(self, symbol, **kwargs):
        """Update trade data"""
        with self.lock:
            if symbol in self.active_trades:
                self.active_trades[symbol].update(kwargs)
    
    def close_trade(self, symbol, exit_price, exit_time=None):
        """Close trade"""
        with self.lock:
            if symbol in self.active_trades:
                trade = self.active_trades.pop(symbol)
                exit_time = exit_time or datetime.utcnow()
                
                # Calculate P&L
                if trade['side'] == 'BUY':
                    pnl = (exit_price - trade['entry_price']) * trade['quantity']
                    pnl_percent = ((exit_price - trade['entry_price']) / trade['entry_price']) * 100
                else:  # SELL
                    pnl = (trade['entry_price'] - exit_price) * trade['quantity']
                    pnl_percent = ((trade['entry_price'] - exit_price) / trade['entry_price']) * 100
                
                duration = (exit_time - trade['entry_time']).total_seconds() / 60  # minutes
                
                closed_trade = {
                    'symbol': symbol,
                    'side': trade['side'],
                    'entry_price': trade['entry_price'],
                    'exit_price': exit_price,
                    'quantity': trade['quantity'],
                    'pnl': pnl,
                    'pnl_percent': pnl_percent,
                    'entry_time': trade['entry_time'],
                    'exit_time': exit_time,
                    'duration_minutes': duration
                }
                
                self.trade_history.append(closed_trade)
                return closed_trade
            return None
    
    def get_active_trades(self):
        """Get active trades"""
        with self.lock:
            return self.active_trades.copy()
    
    def get_trade_history(self, limit=None):
        """Get trade history"""
        with self.lock:
            if limit:
                return self.trade_history[-limit:]
            return self.trade_history.copy()

class BinanceAPI:
    """Binance API handler with error management"""
    def __init__(self, api_key, api_secret, testnet=True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.client = None
        self.connect()
    
    def connect(self):
        """Connect to Binance"""
        try:
            self.client = Client(self.api_key, self.api_secret, testnet=self.testnet)
            logger.info("Connected to Binance API successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Binance API: {str(e)}")
            return False
    
    def get_price(self, symbol, retries=3):
        """Get market price"""
        for attempt in range(retries):
            try:
                ticker = self.client.get_symbol_ticker(symbol=symbol)
                return float(ticker['price'])
            except BinanceAPIException as e:
                logger.error(f"API error getting price: {e.status_code} - {e.message}")
                if e.status_code == 429:  # Rate limit
                    time.sleep(10)
            except Exception as e:
                logger.error(f"Error getting price: {str(e)}")
                if attempt < retries - 1:
                    time.sleep(2)
        return None
    
    def get_klines(self, symbol, interval, limit, retries=3):
        """Get candlestick data"""
        for attempt in range(retries):
            try:
                return self.client.get_klines(symbol=symbol, interval=interval, limit=limit)
            except BinanceAPIException as e:
                logger.error(f"API error getting klines: {e.status_code} - {e.message}")
                if e.status_code == 429:
                    time.sleep(10)
            except Exception as e:
                logger.error(f"Error getting klines: {str(e)}")
                if attempt < retries - 1:
                    time.sleep(2)
        return None
    
    def create_order(self, symbol, side, quantity, order_type=Client.ORDER_TYPE_MARKET, **kwargs):
        """Create trading order"""
        try:
            order = self.client.create_order(
                symbol=symbol,
                side=side,
                type=order_type,
                quantity=quantity,
                **kwargs
            )
            logger.info(f"Order executed: {order}")
            return order
        except Exception as e:
            logger.error(f"Error creating order: {str(e)}")
        return None
    
    def get_asset_balance(self, asset, retries=3):
        """Get asset balance"""
        for attempt in range(retries):
            try:
                balance = self.client.get_asset_balance(asset=asset)
                if balance:
                    return {'asset': balance['asset'], 'free': float(balance['free']), 'locked': float(balance['locked'])}
                return None
            except Exception as e:
                logger.error(f"Error getting balance: {str(e)}")
                if attempt < retries - 1:
                    time.sleep(2)
        return None

class TelegramNotifier:
    """Telegram notifications handler"""
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.session = requests.Session()
        self.session.timeout = 10
    
    def send_message(self, text, parse_mode='HTML'):
        """Send message to Telegram"""
        if not self.token or not self.chat_id:
            return False
        
        url = f"{self.base_url}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": True
        }
        
        try:
            response = self.session.post(url, json=payload)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Error sending Telegram message: {str(e)}")
            return False

class TradingBot:
    """Main trading bot class"""
    def __init__(self, api_key, api_secret, telegram_token=None, telegram_chat_id=None, config=None):
        self.config = TradingBotConfig()
        if config:
            self.config.config.update(config)
        
        self.api = BinanceAPI(api_key, api_secret, testnet=True)
        self.trade_manager = TradeManager()
        self.telegram = TelegramNotifier(telegram_token, telegram_chat_id) if telegram_token else None
        
        self.running = False
        self.start_time = None
        self.last_activity = None
        
    def calculate_sma(self, prices, window):
        """Calculate Simple Moving Average"""
        if len(prices) < window:
            return None
        return sum(prices[-window:]) / window
    
    def calculate_rsi(self, prices, period=14):
        """Calculate RSI"""
        if len(prices) < period + 1:
            return None
        
        deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        gains = [d if d > 0 else 0 for d in deltas]
        losses = [-d if d < 0 else 0 for d in deltas]
        
        avg_gain = sum(gains[-period:]) / period
        avg_loss = sum(losses[-period:]) / period
        
        if avg_loss == 0:
            return 100
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def should_buy(self, symbol):
        """Check if should buy based on strategy"""
        strategy = self.config.get('strategy')
        
        # Get historical data
        klines = self.api.get_klines(symbol, Client.KLINE_INTERVAL_1HOUR, 100)
        if not klines:
            return False
        
        prices = [float(k[4]) for k in klines]  # Close prices
        
        if strategy == 'SMA_CROSSOVER':
            settings = self.config.get('indicator_settings')['SMA_CROSSOVER']
            short_sma = self.calculate_sma(prices, settings['short_window'])
            long_sma = self.calculate_sma(prices, settings['long_window'])
            
            if short_sma and long_sma:
                return short_sma > long_sma * (1 + settings['threshold'])
        
        elif strategy == 'RSI':
            settings = self.config.get('indicator_settings')['RSI']
            rsi = self.calculate_rsi(prices, settings['period'])
            
            if rsi:
                return rsi < settings['oversold']
        
        return False
    
    def should_sell(self, symbol):
        """Check if should sell based on strategy"""
        strategy = self.config.get('strategy')
        
        # Get historical data
        klines = self.api.get_klines(symbol, Client.KLINE_INTERVAL_1HOUR, 100)
        if not klines:
            return False
        
        prices = [float(k[4]) for k in klines]  # Close prices
        
        if strategy == 'SMA_CROSSOVER':
            settings = self.config.get('indicator_settings')['SMA_CROSSOVER']
            short_sma = self.calculate_sma(prices, settings['short_window'])
            long_sma = self.calculate_sma(prices, settings['long_window'])
            
            if short_sma and long_sma:
                return short_sma < long_sma * (1 - settings['threshold'])
        
        elif strategy == 'RSI':
            settings = self.config.get('indicator_settings')['RSI']
            rsi = self.calculate_rsi(prices, settings['period'])
            
            if rsi:
                return rsi > settings['overbought']
        
        return False
    
    def execute_trade(self, symbol, side, quantity):
        """Execute a trade"""
        try:
            order = self.api.create_order(symbol, side, quantity)
            if order:
                price = float(order.get('fills', [{}])[0].get('price', 0))
                if price > 0:
                    self.trade_manager.add_trade(symbol, side, price, quantity)
                    
                    # Send notification
                    if self.telegram:
                        message = f"🔄 Trade Executed\n"
                        message += f"Symbol: {symbol}\n"
                        message += f"Side: {side}\n"
                        message += f"Quantity: {quantity}\n"
                        message += f"Price: {price}\n"
                        message += f"Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
                        self.telegram.send_message(message)
                    
                    return True
        except Exception as e:
            logger.error(f"Error executing trade: {str(e)}")
        return False
    
    def run(self):
        """Main bot loop"""
        self.running = True
        self.start_time = datetime.utcnow()
        
        logger.info("Trading bot started")
        
        if self.telegram:
            self.telegram.send_message("🚀 Trading Bot Started")
        
        while self.running:
            try:
                if not self.config.get('bot_active'):
                    time.sleep(60)
                    continue
                
                symbol = self.config.get('symbol')
                current_price = self.api.get_price(symbol)
                
                if current_price:
                    self.last_activity = datetime.utcnow()
                    
                    # Check for buy signal
                    if self.should_buy(symbol):
                        # Calculate position size
                        risk_percent = self.config.get('risk_percent')
                        # This is a simplified calculation
                        quantity = 0.001  # Example quantity
                        
                        logger.info(f"Buy signal detected for {symbol}")
                        self.execute_trade(symbol, Client.SIDE_BUY, quantity)
                    
                    # Check for sell signal
                    elif self.should_sell(symbol):
                        # Check if we have an open position
                        active_trades = self.trade_manager.get_active_trades()
                        if symbol in active_trades:
                            trade = active_trades[symbol]
                            if trade['side'] == 'BUY':
                                logger.info(f"Sell signal detected for {symbol}")
                                self.execute_trade(symbol, Client.SIDE_SELL, trade['quantity'])
                                self.trade_manager.close_trade(symbol, current_price)
                
                time.sleep(60)  # Check every minute
                
            except Exception as e:
                logger.error(f"Error in bot loop: {str(e)}")
                time.sleep(60)
        
        logger.info("Trading bot stopped")
    
    def stop(self):
        """Stop the bot"""
        self.running = False
        if self.telegram:
            self.telegram.send_message("🛑 Trading Bot Stopped")
    
    def get_status(self):
        """Get bot status"""
        uptime = 0
        if self.start_time:
            uptime = (datetime.utcnow() - self.start_time).total_seconds()
        
        trades = self.trade_manager.get_trade_history()
        total_pnl = sum(trade.get('pnl', 0) for trade in trades)
        
        return {
            "running": self.running,
            "uptime": uptime,
            "trades_count": len(trades),
            "profit_loss": total_pnl,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None
        }
    
    def get_trade_history(self):
        """Get trade history"""
        return self.trade_manager.get_trade_history()
