// Global variables
let botStatus = {
    running: false,
    uptime: 0,
    trades_count: 0,
    profit_loss: 0,
    last_activity: null
};

// DOM elements
const startBotBtn = document.getElementById('start-bot');
const stopBotBtn = document.getElementById('stop-bot');
const testConnectionBtn = document.getElementById('test-connection');
const configForm = document.getElementById('config-form');
const alertModal = new bootstrap.Modal(document.getElementById('alertModal'));

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    startStatusUpdates();
});

function initializeApp() {
    // Load initial configuration
    loadConfiguration();
    
    // Update initial status
    updateBotStatus();
    
    // Setup navigation
    setupNavigation();
    
    console.log('Trading Bot Interface Initialized');
}

function setupEventListeners() {
    // Bot control buttons
    startBotBtn.addEventListener('click', startBot);
    stopBotBtn.addEventListener('click', stopBot);
    testConnectionBtn.addEventListener('click', testConnection);
    
    // Configuration form
    if (configForm) {
        configForm.addEventListener('submit', saveConfiguration);
    }
    
    // API keys save button
    const saveApiKeysBtn = document.getElementById('save-api-keys');
    if (saveApiKeysBtn) {
        saveApiKeysBtn.addEventListener('click', saveApiKeys);
    }
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href').substring(1);
            showSection(target);
            
            // Update active navigation
            document.querySelectorAll('.nav-link').forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function setupNavigation() {
    // Show dashboard by default
    showSection('dashboard');
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
}

function showAlert(message, type = 'info') {
    const alertMessage = document.getElementById('alert-message');
    alertMessage.textContent = message;
    
    // Update modal header color based on type
    const modalHeader = document.querySelector('#alertModal .modal-header');
    modalHeader.className = `modal-header bg-${type}`;
    
    alertModal.show();
}

function startBot() {
    if (botStatus.running) {
        showAlert('الروبوت يعمل بالفعل!', 'warning');
        return;
    }
    
    // Show loading state
    startBotBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التشغيل...';
    startBotBtn.disabled = true;
    
    fetch('/api/start_bot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert(data.message, 'success');
            updateBotStatus();
        } else {
            showAlert(data.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('خطأ في الاتصال: ' + error.message, 'danger');
    })
    .finally(() => {
        // Reset button state
        startBotBtn.innerHTML = '<i class="fas fa-play"></i> تشغيل الروبوت';
        startBotBtn.disabled = false;
    });
}

function stopBot() {
    if (!botStatus.running) {
        showAlert('الروبوت غير يعمل حالياً!', 'warning');
        return;
    }
    
    // Show loading state
    stopBotBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإيقاف...';
    stopBotBtn.disabled = true;
    
    fetch('/api/stop_bot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert(data.message, 'success');
            updateBotStatus();
        } else {
            showAlert(data.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('خطأ في الاتصال: ' + error.message, 'danger');
    })
    .finally(() => {
        // Reset button state
        stopBotBtn.innerHTML = '<i class="fas fa-stop"></i> إيقاف الروبوت';
        stopBotBtn.disabled = false;
    });
}

function testConnection() {
    // Show loading state
    testConnectionBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الاختبار...';
    testConnectionBtn.disabled = true;
    
    fetch('/api/test_connection', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert('تم الاتصال بنجاح مع Binance API!', 'success');
        } else {
            showAlert('فشل الاتصال: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('خطأ في الاتصال: ' + error.message, 'danger');
    })
    .finally(() => {
        // Reset button state
        testConnectionBtn.innerHTML = '<i class="fas fa-link"></i> اختبار الاتصال';
        testConnectionBtn.disabled = false;
    });
}

function loadConfiguration() {
    fetch('/api/config')
        .then(response => response.json())
        .then(config => {
            // Update form fields
            if (document.getElementById('symbol')) {
                document.getElementById('symbol').value = config.symbol || 'BTCUSDT';
            }
            if (document.getElementById('risk-percent-input')) {
                document.getElementById('risk-percent-input').value = (config.risk_percent || 0.01) * 100;
            }
            if (document.getElementById('strategy')) {
                document.getElementById('strategy').value = config.strategy || 'SMA_CROSSOVER';
            }
            if (document.getElementById('bot-active')) {
                document.getElementById('bot-active').checked = config.bot_active !== false;
            }
            
            // Update risk management fields
            if (config.risk_management) {
                const rm = config.risk_management;
                if (document.getElementById('max-daily-risk')) {
                    document.getElementById('max-daily-risk').value = (rm.max_daily_risk || 0.05) * 100;
                }
                if (document.getElementById('stop-loss')) {
                    document.getElementById('stop-loss').value = rm.stop_loss || 1.0;
                }
                if (document.getElementById('trailing-stop')) {
                    document.getElementById('trailing-stop').checked = rm.trailing_stop !== false;
                }
            }
            
            // Update quick info
            updateQuickInfo(config);
        })
        .catch(error => {
            console.error('Error loading configuration:', error);
        });
}

function saveConfiguration(e) {
    e.preventDefault();
    
    const config = {
        symbol: document.getElementById('symbol').value,
        risk_percent: parseFloat(document.getElementById('risk-percent-input').value) / 100,
        strategy: document.getElementById('strategy').value,
        bot_active: document.getElementById('bot-active').checked,
        risk_management: {
            max_daily_risk: parseFloat(document.getElementById('max-daily-risk').value) / 100,
            stop_loss: parseFloat(document.getElementById('stop-loss').value),
            trailing_stop: document.getElementById('trailing-stop').checked,
            dynamic_risk: true,
            trail_percent: 0.5
        }
    };
    
    fetch('/api/config', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(config)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert(data.message, 'success');
            updateQuickInfo(config);
        } else {
            showAlert(data.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('خطأ في حفظ الإعدادات: ' + error.message, 'danger');
    });
}

function updateQuickInfo(config) {
    if (document.getElementById('current-symbol')) {
        document.getElementById('current-symbol').textContent = config.symbol || 'BTCUSDT';
    }
    if (document.getElementById('current-strategy')) {
        document.getElementById('current-strategy').textContent = config.strategy || 'SMA_CROSSOVER';
    }
    if (document.getElementById('risk-percent')) {
        document.getElementById('risk-percent').textContent = ((config.risk_percent || 0.01) * 100).toFixed(1) + '%';
    }
}

function updateBotStatus() {
    fetch('/api/bot_status')
        .then(response => response.json())
        .then(data => {
            botStatus = data;
            
            // Update status display
            const statusElement = document.getElementById('bot-status');
            if (statusElement) {
                statusElement.textContent = data.running ? 'يعمل' : 'متوقف';
                statusElement.className = data.running ? 'text-success' : 'text-danger';
            }
            
            // Update other status information
            if (document.getElementById('total-pnl')) {
                document.getElementById('total-pnl').textContent = '$' + data.profit_loss.toFixed(2);
                document.getElementById('total-pnl').className = data.profit_loss >= 0 ? 'text-success' : 'text-danger';
            }
            
            if (document.getElementById('trades-count')) {
                document.getElementById('trades-count').textContent = data.trades_count;
            }
            
            if (document.getElementById('uptime')) {
                document.getElementById('uptime').textContent = formatUptime(data.uptime);
            }
            
            if (document.getElementById('last-activity')) {
                document.getElementById('last-activity').textContent = data.last_activity ? 
                    new Date(data.last_activity).toLocaleString('ar-SA') : 'غير متاح';
            }
            
            // Update button states
            updateButtonStates(data.running);
        })
        .catch(error => {
            console.error('Error updating bot status:', error);
        });
}

function updateButtonStates(running) {
    if (startBotBtn) {
        startBotBtn.disabled = running;
        startBotBtn.classList.toggle('btn-secondary', running);
        startBotBtn.classList.toggle('btn-success', !running);
    }
    
    if (stopBotBtn) {
        stopBotBtn.disabled = !running;
        stopBotBtn.classList.toggle('btn-secondary', !running);
        stopBotBtn.classList.toggle('btn-danger', running);
    }
}

function loadTrades() {
    fetch('/api/trades')
        .then(response => response.json())
        .then(trades => {
            updateTradesTable(trades);
        })
        .catch(error => {
            console.error('Error loading trades:', error);
        });
}

function updateTradesTable(trades) {
    const tradesTable = document.getElementById('trades-table');
    if (!tradesTable) return;
    
    tradesTable.innerHTML = '';
    
    if (trades.length === 0) {
        tradesTable.innerHTML = '<tr><td colspan="7" class="text-center">لا توجد صفقات حتى الآن</td></tr>';
        return;
    }
    
    trades.forEach(trade => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${trade.symbol}</td>
            <td><span class="badge ${trade.side === 'BUY' ? 'bg-success' : 'bg-danger'}">${trade.side}</span></td>
            <td>$${trade.entry_price.toFixed(2)}</td>
            <td>$${trade.exit_price ? trade.exit_price.toFixed(2) : 'N/A'}</td>
            <td>${trade.quantity}</td>
            <td class="${trade.pnl >= 0 ? 'text-success' : 'text-danger'}">
                ${trade.pnl >= 0 ? '+' : ''}$${trade.pnl.toFixed(2)} (${trade.pnl_percent.toFixed(2)}%)
            </td>
            <td>${new Date(trade.entry_time).toLocaleString('ar-SA')}</td>
        `;
        tradesTable.appendChild(row);
    });
}

function formatUptime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function startStatusUpdates() {
    // Update status every 10 seconds
    setInterval(updateBotStatus, 10000);
    
    // Update trades every 30 seconds
    setInterval(loadTrades, 30000);
    
    // Initial load
    loadTrades();
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatPercent(value) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'percent',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(value / 100);
}

function saveApiKeys() {
    const apiKey = document.getElementById('api-key').value;
    const apiSecret = document.getElementById('api-secret').value;
    const telegramToken = document.getElementById('telegram-token').value;
    const telegramChatId = document.getElementById('telegram-chat-id').value;
    const testnetMode = document.getElementById('testnet-mode').checked;
    
    if (!apiKey || !apiSecret) {
        showAlert('يرجى إدخال مفتاح API والمفتاح السري', 'warning');
        return;
    }
    
    // Show loading state
    const saveBtn = document.getElementById('save-api-keys');
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
    saveBtn.disabled = true;
    
    const apiData = {
        api_key: apiKey,
        api_secret: apiSecret,
        telegram_token: telegramToken,
        telegram_chat_id: telegramChatId,
        testnet: testnetMode
    };
    
    fetch('/api/save_api_keys', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(apiData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert('تم حفظ مفاتيح API بنجاح!', 'success');
            // Clear the form fields for security
            document.getElementById('api-key').value = '';
            document.getElementById('api-secret').value = '';
            document.getElementById('telegram-token').value = '';
            document.getElementById('telegram-chat-id').value = '';
        } else {
            showAlert('خطأ في حفظ مفاتيح API: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('خطأ في الاتصال: ' + error.message, 'danger');
    })
    .finally(() => {
        // Reset button state
        saveBtn.innerHTML = '<i class="fas fa-save"></i> حفظ مفاتيح API';
        saveBtn.disabled = false;
    });
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    showAlert('حدث خطأ في التطبيق. يرجى تحديث الصفحة.', 'danger');
});

// Handle online/offline status
window.addEventListener('online', function() {
    showAlert('تم استعادة الاتصال بالإنترنت', 'success');
});

window.addEventListener('offline', function() {
    showAlert('تم فقدان الاتصال بالإنترنت', 'warning');
});

console.log('Trading Bot Interface Script Loaded');
