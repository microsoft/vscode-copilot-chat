#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script to run the trading bot directly without web interface
"""

import os
import sys
import time
import json
import logging
from trading_bot import TradingBot
from config import Config

def main():
    """Main function to run the trading bot"""
    print("=" * 60)
    print("           روبوت تداول Binance المتقدم")
    print("=" * 60)
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('trading_bot.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    logger = logging.getLogger(__name__)
    
    # Load configuration
    config_data = Config.load_config()
    logger.info("Configuration loaded successfully")
    
    # Validate API credentials
    valid, message = Config.validate_credentials()
    if not valid:
        logger.error(f"Credential validation failed: {message}")
        print(f"\n❌ خطأ: {message}")
        print("\nيرجى تعيين متغيرات البيئة التالية:")
        print("- BINANCE_API_KEY")
        print("- BINANCE_API_SECRET")
        print("- TELEGRAM_BOT_TOKEN (اختياري)")
        print("- TELEGRAM_CHAT_ID (اختياري)")
        return
    
    logger.info("API credentials validated successfully")
    
    # Get credentials
    credentials = Config.get_api_credentials()
    
    # Create bot instance
    try:
        bot = TradingBot(
            api_key=credentials['api_key'],
            api_secret=credentials['api_secret'],
            telegram_token=credentials['telegram_token'],
            telegram_chat_id=credentials['telegram_chat_id'],
            config=config_data
        )
        
        logger.info("Trading bot initialized successfully")
        print("\n✅ تم تهيئة الروبوت بنجاح")
        print(f"الرمز: {config_data.get('symbol', 'BTCUSDT')}")
        print(f"الاستراتيجية: {config_data.get('strategy', 'SMA_CROSSOVER')}")
        print(f"نسبة المخاطرة: {config_data.get('risk_percent', 0.01) * 100}%")
        print(f"وضع التجربة: {'نعم' if config_data.get('testnet', True) else 'لا'}")
        
        # Start the bot
        print("\n🚀 بدء تشغيل الروبوت...")
        print("اضغط Ctrl+C لإيقاف الروبوت\n")
        
        bot.run()
        
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        print("\n🛑 تم إيقاف الروبوت بواسطة المستخدم")
        if 'bot' in locals():
            bot.stop()
    except Exception as e:
        logger.error(f"Error running bot: {str(e)}")
        print(f"\n❌ خطأ في تشغيل الروبوت: {str(e)}")
    
    print("\n👋 شكراً لاستخدام روبوت التداول")

if __name__ == "__main__":
    main()
