#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Flask Web Interface for Binance Trading Bot
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import json
import os
import threading
import time
from datetime import datetime
import logging
from trading_bot import TradingBot
from config import Config

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'default_secret_key_for_demo')

# Global bot instance
bot_instance = None
bot_thread = None
bot_running = False

# Global API keys storage (session-based)
api_keys_storage = {}

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_config():
    """Load bot configuration"""
    try:
        with open('bot_config.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_config(config_data):
    """Save bot configuration"""
    try:
        with open('bot_config.json', 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        logger.error(f"Error saving config: {e}")
        return False

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """Dashboard page"""
    config_data = load_config()
    return render_template('dashboard.html', config=config_data)

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get current configuration"""
    config_data = load_config()
    return jsonify(config_data)

@app.route('/api/config', methods=['POST'])
def update_config():
    """Update configuration"""
    try:
        config_data = request.json
        if save_config(config_data):
            return jsonify({"status": "success", "message": "تم حفظ الإعدادات بنجاح"})
        else:
            return jsonify({"status": "error", "message": "فشل في حفظ الإعدادات"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/save_api_keys', methods=['POST'])
def save_api_keys():
    """Save API keys temporarily in session"""
    try:
        data = request.json
        session_id = session.get('session_id', str(time.time()))
        
        # Store API keys in session storage
        api_keys_storage[session_id] = {
            'api_key': data.get('api_key'),
            'api_secret': data.get('api_secret'),
            'telegram_token': data.get('telegram_token'),
            'telegram_chat_id': data.get('telegram_chat_id'),
            'testnet': data.get('testnet', True)
        }
        
        session['session_id'] = session_id
        
        return jsonify({"status": "success", "message": "تم حفظ مفاتيح API بنجاح"})
        
    except Exception as e:
        logger.error(f"Error saving API keys: {e}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/start_bot', methods=['POST'])
def start_bot():
    """Start the trading bot"""
    global bot_instance, bot_thread, bot_running
    
    try:
        if bot_running:
            return jsonify({"status": "error", "message": "الروبوت يعمل بالفعل"})
        
        # Load configuration
        config_data = load_config()
        
        # Get API credentials from session or environment
        session_id = session.get('session_id')
        api_keys = api_keys_storage.get(session_id) if session_id else None
        
        if api_keys:
            # Use keys from session (manual entry)
            api_key = api_keys['api_key']
            api_secret = api_keys['api_secret']
            telegram_token = api_keys.get('telegram_token')
            telegram_chat_id = api_keys.get('telegram_chat_id')
            testnet = api_keys.get('testnet', True)
        else:
            # Fallback to environment variables
            api_key = os.environ.get('BINANCE_API_KEY')
            api_secret = os.environ.get('BINANCE_API_SECRET')
            telegram_token = os.environ.get('TELEGRAM_BOT_TOKEN')
            telegram_chat_id = os.environ.get('TELEGRAM_CHAT_ID')
            testnet = config_data.get('testnet', True)
        
        if not api_key or not api_secret:
            return jsonify({"status": "error", "message": "يرجى إدخال مفاتيح API أولاً من صفحة الإعدادات"})
        
        # Update config with testnet setting
        config_data['testnet'] = testnet
        
        # Create bot instance
        bot_instance = TradingBot(
            api_key=api_key,
            api_secret=api_secret,
            telegram_token=telegram_token,
            telegram_chat_id=telegram_chat_id,
            config=config_data
        )
        
        # Start bot in separate thread
        bot_thread = threading.Thread(target=bot_instance.run)
        bot_thread.daemon = True
        bot_thread.start()
        
        bot_running = True
        return jsonify({"status": "success", "message": "تم تشغيل الروبوت بنجاح"})
        
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/stop_bot', methods=['POST'])
def stop_bot():
    """Stop the trading bot"""
    global bot_instance, bot_running
    
    try:
        if not bot_running:
            return jsonify({"status": "error", "message": "الروبوت غير يعمل"})
        
        if bot_instance:
            bot_instance.stop()
            bot_running = False
            return jsonify({"status": "success", "message": "تم إيقاف الروبوت"})
        
        return jsonify({"status": "error", "message": "مثيل الروبوت غير موجود"})
        
    except Exception as e:
        logger.error(f"Error stopping bot: {e}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/bot_status', methods=['GET'])
def bot_status():
    """Get bot status"""
    global bot_running, bot_instance
    
    status = {
        "running": bot_running,
        "uptime": 0,
        "trades_count": 0,
        "profit_loss": 0.0,
        "last_activity": None
    }
    
    if bot_instance and bot_running:
        status.update(bot_instance.get_status())
    
    return jsonify(status)

@app.route('/api/trades', methods=['GET'])
def get_trades():
    """Get trading history"""
    global bot_instance
    
    trades = []
    if bot_instance:
        trades = bot_instance.get_trade_history()
    
    return jsonify(trades)

@app.route('/api/test_connection', methods=['POST'])
def test_connection():
    """Test Binance API connection"""
    try:
        # Get API credentials from session or environment
        session_id = session.get('session_id')
        api_keys = api_keys_storage.get(session_id) if session_id else None
        
        if api_keys:
            # Use keys from session (manual entry)
            api_key = api_keys['api_key']
            api_secret = api_keys['api_secret']
            testnet = api_keys.get('testnet', True)
        else:
            # Fallback to environment variables
            api_key = os.environ.get('BINANCE_API_KEY')
            api_secret = os.environ.get('BINANCE_API_SECRET')
            testnet = True
        
        if not api_key or not api_secret:
            return jsonify({"status": "error", "message": "يرجى إدخال مفاتيح API أولاً من صفحة الإعدادات"})
        
        # Test connection
        try:
            from binance.client import Client
            client = Client(api_key, api_secret, testnet=testnet)
            account = client.get_account()
            
            return jsonify({
                "status": "success", 
                "message": f"تم الاتصال بنجاح ({'وضع التجربة' if testnet else 'وضع التداول الحقيقي'})",
                "testnet": testnet,
                "account_type": account.get('accountType', 'Unknown')
            })
        except ImportError:
            return jsonify({"status": "error", "message": "مكتبة Binance غير متوفرة"})
        
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
